package fhkiel.oopsemesterprojekt.enp.OOPProjekt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OopProjektApplication {

	public static void main(String[] args) {
		SpringApplication.run(OopProjektApplication.class, args);
	}

}
