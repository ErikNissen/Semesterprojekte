package fhkiel.oopsemesterprojekt.enp.OOPProjekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OopProjektApplicationTests {

	@Test
	void contextLoads() {
	}

}
